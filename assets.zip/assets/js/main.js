$(document).ready(function(){

paypal.Button.render(
    {
        
        env:'production',
        style:{
            label:'paypal',
            size:'medium',
            shape:'rect',
            color:'blue',
            tagline:'false'
        },
        client:{
            sandbox:'AVJW7v2uPwuueCXr038tQqyJt92oVbULVU3lLL17iywwK12PIpNkztQhq386A7EHAVtin_w06xW0NBSC',
            production:'ASEkXsE1NUHmUybQs-1rTJNlutmDERCNBlVl9cT0xTeE7EPkWB2WGhXSthjbSTqhweo7B144hNkchRGO'
            
        },
        commit:true,
        payment: function(data,action)
        {
            return actions.payment.create({
                payment:{
                    transactions:[
                        {
                            amount:{
                                total:'100',
                                currency:'USD'
                            }
                        }
                        ]
                }});
                
        } ,
        onAuthorize: function(data,actions){
            
            return actions.payment.execute().then(function(payment){
                var path="http://eavni93.com/itay/pay.php";
                $.ajax({
                    type:'POST',
                    url:path,
                    data:{
                        tid:payment.id,
                        state:payment.state
                    },
                    success:function(response){
                        console.log(response);
                        if(response=='success')
                        {
                            $('#payment-success').html('payment sucess');
                            setTimeout(function(){
                                window.location.href="eavni93.com/index.php";
                            },2500);
                        }
                    }
                    
                });
            });
        }
    },'#btn-paypal');
});